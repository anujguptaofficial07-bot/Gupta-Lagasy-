# Gupta Legacy Vyapar AI - Pro User Friendly UI

Updated app UI to actual mobile app format, not phone mockup inside browser.

Pages included:
- Welcome
- Dashboard
- Pvt. Ltd. Documents checklist
- Management hierarchy
- Vyapar AI analytics
- Company Profile
- Sales entry
- Stock
- Reports
- Calculator
- AI Upload placeholder
- Settings

Works offline as HTML/WebView. Data saves in localStorage. Android project is in android-app and GitHub Actions workflow builds APK/AAB.

## Login Flow Update
- App now starts with Gupta Legacy animated loading screen.
- After animation, login page appears.
- Login/Demo Login opens Dashboard directly.
- Logout button added in Settings.
