# Developer Tasks

## Phase 1: MVP Production
- Replace WebView prototype with Flutter or native Kotlin if long-term scalability is required.
- Connect Firebase Auth.
- Store sales/stocks/monthly records in Firestore per user.
- Deploy backend functions and set GEMINI_API_KEY as a server secret.
- Implement AI upload endpoint and clean JSON validation.

- Test Gemini extraction with clear bill photo, blurry photo, and monthly profit PDF.

## Phase 3: Quality
- Add Firebase Crashlytics.
- Add Analytics events.
- Add offline cache and sync conflict handling.
- Test low-end devices.
- Compress images and keep bundle size small.

## Phase 4: Growth
- Add referral system.
- Add WhatsApp report sharing.
- Add multi-shop and staff login.
