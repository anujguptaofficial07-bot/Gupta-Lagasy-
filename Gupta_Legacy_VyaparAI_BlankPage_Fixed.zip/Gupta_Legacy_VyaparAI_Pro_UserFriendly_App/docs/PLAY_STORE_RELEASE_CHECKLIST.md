# Play Store Release Checklist for Vyapar AI

1. Final app name: Vyapar AI
2. Package name: com.vyaparai.app
3. Create Google Play Console developer account
4. Create Firebase project
5. Add Android app to Firebase
6. Enable Firebase Auth
7. Enable Firestore
8. Deploy backend extract endpoint
9. Replace placeholder support email
13. Add privacy policy URL
14. Fill Data Safety form
15. Create app icon, feature graphic, screenshots
16. Test on low-end Android device, average Android device and emulator
17. Upload signed AAB to internal testing
19. Fix crashes and ANRs
20. Publish to production
