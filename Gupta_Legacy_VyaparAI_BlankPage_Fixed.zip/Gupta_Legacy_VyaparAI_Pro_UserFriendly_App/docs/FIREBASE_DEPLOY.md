# Firebase Functions deploy for Vyapar AI Gemini backend

Firebase Console me direct ZIP upload se backend deploy nahi hota. Is folder ko Firebase CLI se deploy karein.

## Requirements

- Firebase project
- Blaze plan enabled for Cloud Functions deploy
- Node.js installed on laptop/PC
- Firebase CLI installed

## Commands

Open terminal in this folder: `VyaparAI_GitHub_Compatible`

```bash
npm install -g firebase-tools
firebase login
firebase use --add
cd backend-firebase-functions
npm install
cp .env.example .env
```

Open `.env` and set:

```text
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-2.0-flash
```

Go back to root and deploy:

```bash
cd ..
firebase deploy --only functions
```

The deployed function URL will look like:

```text
https://asia-south1-YOUR_PROJECT_ID.cloudfunctions.net/api
```

Paste this full app endpoint in Vyapar AI Developer Mode:

```text
https://asia-south1-YOUR_PROJECT_ID.cloudfunctions.net/api/extractBill
```

Health test URL:

```text
https://asia-south1-YOUR_PROJECT_ID.cloudfunctions.net/api/health
```
