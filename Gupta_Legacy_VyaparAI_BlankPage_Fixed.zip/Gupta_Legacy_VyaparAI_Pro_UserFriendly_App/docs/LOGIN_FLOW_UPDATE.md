# Login Flow Update

Flow added as requested:

1. App launch animation / secure workspace loading
2. Login page
3. Login success animation
4. Dashboard opens automatically

Notes:
- Login data is stored locally in browser/WebView localStorage.
- Demo Login is included for quick testing.
- Settings page has Logout option.
