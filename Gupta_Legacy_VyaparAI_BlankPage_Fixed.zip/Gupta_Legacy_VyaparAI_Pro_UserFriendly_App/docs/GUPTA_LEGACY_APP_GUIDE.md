# Gupta Legacy App Guide

This app combines a Gupta Legacy corporate management layer with the Vyapar AI business engine.

## Pages
1. **Welcome** - premium brand landing page and quick start.
2. **Dashboard** - company profile, mockup preview and shortcut cards.
3. **Pvt Docs** - Pvt. Ltd. document checklist with progress.
4. **Team** - founder/director/management hierarchy and editable posts.
5. **Vyapar AI** - sales, profit, inventory and AI assistant overview.
6. **AI Upload** - image/PDF/CSV/JSON import using the Gemini endpoint.
7. **Sales** - manual sale and monthly profit entry.
8. **Reports** - graphs, valuation and 10-year plan.
9. **Calc** - normal and code-word calculator.
10. **Settings** - light/dark mode, liquid glass control, performance mode, backup and hidden developer endpoint.

## Gemini endpoint
Tap the logo 7 times to show Developer Mode in Settings, then save the backend Gemini extraction endpoint.

## Note
The Pvt. Ltd. documents list is a planning checklist. Ask a CA/CS before filing anything on MCA.
