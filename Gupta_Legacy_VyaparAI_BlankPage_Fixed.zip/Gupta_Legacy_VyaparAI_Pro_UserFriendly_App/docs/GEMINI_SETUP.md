# Vyapar AI Gemini Setup

## What changed

This ZIP uses a server-side Gemini backend for AI Upload.

The app flow is:

```text
Android/Web app → /extractBill backend → Gemini API → structured JSON → app import
```

Your Gemini API key is **not** stored in `web/index.html` or Android assets. Keep it only on the backend/server.

## Files changed

```text
backend-firebase-functions/index.js
backend-firebase-functions/.env.example
backend-firebase-functions/package.json
web/index.html
android-app/app/src/main/assets/index.html
```

## Local backend test

```bash
cd backend-firebase-functions
npm install
cp .env.example .env
```

Open `.env` and paste your Google AI Studio key:

```text
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-2.0-flash
```

Then run:

```bash
npm start
```

Health URL:

```text
http://localhost:3000/health
```

AI Extract Endpoint for app Developer Mode:

```text
http://localhost:3000/extractBill
```

For Android phone testing, localhost on your phone is not your laptop. Deploy backend online first, or use a tunnel/hosting URL.

## Deploy backend

Deploy `backend-firebase-functions/` on any Node 20 hosting such as Cloud Run, Render, Railway, Firebase/Google Cloud Function, or VPS.

Set environment variables on the server:

```text
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-2.0-flash
```

After deployment, your endpoint will look like:

```text
https://your-domain.com/extractBill
```

## Enable in app

1. Open Vyapar AI.
2. Tap logo 7 times to unlock Developer Mode.
3. Go to Settings.
4. Paste your deployed endpoint in **Gemini Extract Endpoint**.
5. Press **Save Endpoint**.
6. Press **Test**.
7. Go to AI Upload and upload a bill/photo/PDF.

## Important

- Never paste Gemini key directly in app frontend.
- If Test says connected but upload fails, check server logs and file size.
- Current backend file upload limit is 12 MB.
- CSV/TXT/JSON imports still work offline without Gemini.
