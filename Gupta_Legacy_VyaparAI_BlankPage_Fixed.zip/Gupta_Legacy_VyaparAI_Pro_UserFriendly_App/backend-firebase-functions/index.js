const { onRequest } = require("firebase-functions/v2/https");
const app = require("./app");

exports.api = onRequest({
  region: "asia-south1",
  timeoutSeconds: 120,
  memory: "512MiB",
  cors: true
}, app);
