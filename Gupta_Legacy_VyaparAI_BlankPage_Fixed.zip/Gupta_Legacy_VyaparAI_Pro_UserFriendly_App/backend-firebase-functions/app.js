const express = require("express");
const cors = require("cors");
const multer = require("multer");
require("dotenv").config();

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 12 * 1024 * 1024 }
});

const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.0-flash";

app.use(cors({ origin: true }));
app.use(express.json({ limit: "2mb" }));

app.get("/health", (req, res) => {
  res.json({
    ok: true,
    app: "Vyapar AI Backend",
    engine: "Gemini",
    model: GEMINI_MODEL,
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY),
    time: new Date().toISOString()
  });
});

app.post("/extractBill", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
    if (!apiKey) {
      return res.status(500).json({
        error: "Gemini API key not configured on server. Add GEMINI_API_KEY in backend environment.",
        sales: [],
        monthlyProfits: [],
        stocks: []
      });
    }

    const data = await extractWithGemini(req.file, apiKey);
    res.json(data);
  } catch (err) {
    console.error("Gemini extraction failed", err);
    res.status(500).json({
      error: err && err.message ? err.message : "Gemini extraction failed",
      sales: [],
      monthlyProfits: [],
      stocks: []
    });
  }
});

async function extractWithGemini(file, apiKey) {
  const base64 = file.buffer.toString("base64");
  const mime = file.mimetype || "application/octet-stream";

  const prompt = `You are Vyapar AI for an Indian footwear/small retail shop.
Read the uploaded bill, sale photo, handwritten note, monthly-profit sheet, PDF, or image.
Return ONLY valid JSON. Do not add markdown, explanation, comments, or extra text.

JSON shape:
{
  "sales": [
    {
      "date": "YYYY-MM-DD",
      "product": "string",
      "category": "Footwear",
      "purchasePrice": 0,
      "sellingPrice": 0,
      "quantity": 1,
      "brand": "string",
      "size": "string",
      "type": "string",
      "articleName": "string",
      "mrp": 0
    }
  ],
  "monthlyProfits": [
    { "month": "YYYY-MM", "profit": 0, "entries": 0, "remark": "string" }
  ],
  "stocks": [
    { "item": "string", "category": "Footwear", "qty": 0, "min": 5 }
  ]
}

Rules:
- If this is a monthly profit/profit table, fill monthlyProfits and do not convert those rows into sales.
- If this is a sale/bill, fill sales with product, quantity, selling price, purchase price if visible, brand/model/article/size/type/MRP if visible.
- If purchase price is not visible, use 0 rather than guessing.
- If date/month is not visible, use today's date ${new Date().toISOString().slice(0, 10)} for sales and current month ${new Date().toISOString().slice(0, 7)} for monthlyProfits only when a profit amount is clearly visible.
- If unsure, return empty arrays for that section.
- Numbers must be numeric, not strings with ₹ or commas.`;

  const requestBody = {
    contents: [
      {
        role: "user",
        parts: [
          { text: prompt },
          { inline_data: { mime_type: mime, data: base64 } }
        ]
      }
    ],
    generationConfig: {
      temperature: 0.1,
      response_mime_type: "application/json"
    }
  };

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent?key=${encodeURIComponent(apiKey)}`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(requestBody)
  });

  const responseText = await response.text();
  if (!response.ok) {
    throw new Error(`Gemini API error ${response.status}: ${shorten(responseText, 600)}`);
  }

  const geminiJson = JSON.parse(responseText);
  const text = extractGeminiText(geminiJson);
  const parsed = parseJsonOnly(text);
  return normalizeExtracted(parsed);
}

function extractGeminiText(payload) {
  const parts = payload && payload.candidates && payload.candidates[0] && payload.candidates[0].content && payload.candidates[0].content.parts;
  if (!Array.isArray(parts)) return "{}";
  return parts.map(part => part.text || "").join("\n").trim() || "{}";
}

function parseJsonOnly(text) {
  const clean = String(text || "{}")
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/```$/i, "")
    .trim();

  try {
    return JSON.parse(clean);
  } catch (firstErr) {
    const match = clean.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]);
    throw firstErr;
  }
}

function normalizeExtracted(input) {
  const obj = input && typeof input === "object" ? input : {};
  return {
    sales: Array.isArray(obj.sales) ? obj.sales.map(normalizeSale).filter(Boolean) : [],
    monthlyProfits: Array.isArray(obj.monthlyProfits) ? obj.monthlyProfits.map(normalizeMonthlyProfit).filter(Boolean) : [],
    stocks: Array.isArray(obj.stocks) ? obj.stocks.map(normalizeStock).filter(Boolean) : []
  };
}

function normalizeSale(row) {
  if (!row || typeof row !== "object") return null;
  return {
    date: stringValue(row.date) || new Date().toISOString().slice(0, 10),
    product: stringValue(row.product || row.item || row.articleName || row.modelName || row.brand) || "Imported item",
    category: stringValue(row.category || row.type) || "Footwear",
    purchasePrice: numberValue(row.purchasePrice || row.buy || row.cost),
    sellingPrice: numberValue(row.sellingPrice || row.salePrice || row.sell || row.amount || row.price),
    quantity: numberValue(row.quantity || row.qty || 1) || 1,
    brand: stringValue(row.brand),
    size: stringValue(row.size),
    type: stringValue(row.type),
    articleName: stringValue(row.articleName || row.article || row.modelName),
    mrp: numberValue(row.mrp || row.MRP)
  };
}

function normalizeMonthlyProfit(row) {
  if (!row || typeof row !== "object") return null;
  const profit = numberValue(row.profit || row.netProfit || row.monthlyProfit || row.amount || row.income);
  const month = normalizeMonth(row.month, row.date);
  if (!profit || !month) return null;
  return {
    month,
    profit,
    entries: row.entries == null ? null : numberValue(row.entries),
    remark: stringValue(row.remark || row.note || row.description)
  };
}

function normalizeStock(row) {
  if (!row || typeof row !== "object") return null;
  const item = stringValue(row.item || row.product || row.name || row.articleName);
  const qty = numberValue(row.qty || row.quantity || row.stockQty || row.qtyInStock);
  if (!item && !qty) return null;
  return {
    item: item || "Imported stock",
    category: stringValue(row.category || row.type) || "Footwear",
    qty,
    min: numberValue(row.min || row.lowStock || row.reorder || 5) || 5
  };
}

function normalizeMonth(month, date) {
  const raw = stringValue(month);
  if (/^\d{4}-\d{2}$/.test(raw)) return raw;
  const fromDate = stringValue(date);
  if (/^\d{4}-\d{2}/.test(fromDate)) return fromDate.slice(0, 7);
  return raw || "";
}

function numberValue(value) {
  if (value === null || value === undefined || value === "") return 0;
  const n = Number(String(value).replace(/[₹,\s]/g, ""));
  return Number.isFinite(n) ? n : 0;
}

function stringValue(value) {
  return value === null || value === undefined ? "" : String(value).trim();
}

function shorten(text, max) {
  const s = String(text || "");
  return s.length > max ? s.slice(0, max) + "..." : s;
}


module.exports = app;
