const app = require("./app");
const port = process.env.PORT || 3000;

app.listen(port, () => {
  console.log(`Vyapar AI Gemini backend running on http://localhost:${port}`);
  console.log(`Health: http://localhost:${port}/health`);
  console.log(`Extract: http://localhost:${port}/extractBill`);
});
