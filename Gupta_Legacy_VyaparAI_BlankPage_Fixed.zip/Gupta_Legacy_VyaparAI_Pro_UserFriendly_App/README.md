# Gupta Legacy Vyapar AI Integrated v2

Premium corporate app based on the Gupta Legacy black + emerald + gold theme.

## Added in this version
- iOS-like liquid glass UI and page animation.
- Multi-page flow: Welcome, Dashboard, Pvt. Ltd. Documents, Management, Vyapar AI, AI Upload, Sales, Reports, Calculator, Settings.
- Image-rich dashboard using the approved mockup style.
- Editable company profile, document checklist and management posts.
- Original Vyapar AI modules retained: AI upload, sales, stock, analytics, calculator and backup.
- GitHub Actions Android APK build workflow included.

## Important
Pvt. Ltd. registration checklist is for planning. Final documents and MCA filing must be verified by a qualified CA/CS.
